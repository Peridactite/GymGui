/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymassignmentthree;

import java.util.ArrayList;

/**
 *
 * @author davwo
 */
public class Gym {
    
    private String owner;
    private String name;
    ArrayList<Member> listM = new ArrayList<Member>();
    private int numMembers = 0;

    public Gym(String owner, String name) {
        //Pcode
        // Initialize owner and name variables to the passed in values
        this.owner = owner;
        this.name = name;
    }
    
    public void addMember(Member guy){
        //Pcode
        /*
        add passed in member to ArrayList listM
        increment number of members
        */
        listM.add(guy);
        numMembers++;
    }
    
    /**
     * Get the value of numMembers
     *
     * @return the value of numMembers
     */
    public int getNumMembers() {
        return numMembers;
    }

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Get the value of owner
     *
     * @return the value of owner
     */
    public String getOwner() {
        return owner;
    }

    public ArrayList<Member> getListM() {
        return listM;
    }
    

}
