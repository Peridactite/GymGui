/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymassignmentthree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author davwo
 */
public class GymAssignmentThree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Gym hotPlace = new Gym("David", "Hot Spot");
        Membership trial = new FreeMonth();
        Member john = new Member(hotPlace, "John", trial, new ArrayList<String>(Arrays.asList("hiking", "rock climbing")));
        Member notjohn = new Member(hotPlace, "Sam", trial, new ArrayList<String>(Arrays.asList("hiking", "rock climbing")));
        System.out.println(hotPlace.getName());
        System.out.println(john.getInterests());
        System.out.println(john.getDays());
        hotPlace.addMember(john);
        hotPlace.addMember(notjohn);
        loopMembers(hotPlace.getListM());
        */

        Scanner scan = new Scanner(System.in);
        System.out.println("Gym Name: ");
        String gymName = scan.nextLine();
        System.out.println("Owner Name: ");
        String owner = scan.nextLine();
        Gym myGym = new Gym(owner, gymName);
        
        addUser(scan, myGym);
        
        boolean running = true;
        while(running){
            System.out.println("What would you like to do next?");
            System.out.println("\tA: Buy a Membership");
            System.out.println("\tB: Sign in");
            System.out.println("\tC: Check a User's balance");
            System.out.println("\tD: Add a member");
            System.out.println("\tE: Exit Program");
            String choice = scan.nextLine();
            if((Character.toLowerCase(choice.charAt(0)) == 'a')){
                pickedA(scan, myGym);
            } else if((Character.toLowerCase(choice.charAt(0)) == 'b')){
                signIn(scan, myGym);
            } else if((Character.toLowerCase(choice.charAt(0)) == 'c')){
                System.out.println("Balance: $" + checkBalance(scan, myGym));
            } else if((Character.toLowerCase(choice.charAt(0)) == 'd')){
                addUser(scan, myGym);
            } else if((Character.toLowerCase(choice.charAt(0)) == 'e')){
                System.out.println("Thank you for using Data Matters Technology.");
                System.exit(0);
            }  
        }//end while running loop
    }
    public static void signIn(Scanner scan, Gym myGym){
        String userName;
        Member user = null;
        boolean exists = false;
        System.out.println("What's your name?");
        userName = scan.nextLine();
        for(Member m : myGym.getListM()){
            if(m.getName().equals(userName) ){
                user = m;
                exists = true;
            }
        }
        if(exists){
            user.signIn();
        } else {
            System.out.println("Please choose a name that exists...");
        } 
    }
    public static double checkBalance(Scanner scan, Gym myGym){
        String userName;
        Member user = null;
        boolean exists = false;
        System.out.println("What's your name?");
        userName = scan.nextLine();
        for(Member m : myGym.getListM()){
            if(m.getName().equals(userName) ){
                user = m;
                exists = true;
            }
        }
        if(exists){
            return user.getBalance();
        } else {
            System.out.println("Please choose a name that exists...");
            return -1;
        }
    }
    public static void addUser(Scanner scan, Gym myGym){
        try {
            System.out.println("Name?");
            String userName = scan.nextLine();
            System.out.println("Membership Length?");
            int length = scan.nextInt();
            while((length != 30) && (length != 90) && (length != 365)){
                System.out.println("Available memberships are 30, 90, and 365 days long. Please choose a valid membership length");
                length = scan.nextInt();
                scan.nextLine();
            }
            Membership memberType = null;
            if(length == 30){
                memberType = new FreeMonth();
            } else if(length == 90){
                memberType = new ThreeMonths();
            } else if(length == 365){
                memberType = new TwelveMonths();
            }
            System.out.println("Interests?");
            String interest = scan.nextLine();
            interest = scan.nextLine();
            ArrayList<String> interestList = new ArrayList<String>();
            interestList.add(interest);
            /*
            while(interest != "stop"){
            System.out.println("And? Say \"stop\" when you're finished");
            interest = scan.nextLine();
            interestList.add(interest);
            }
            //instructor help
            */
            System.out.println("Thank you for registering!");
            Member user = new Member(myGym, userName, memberType, interestList);
            myGym.addMember(user);
            System.out.println("Building new profile...");
            System.out.print("Loading");
            Thread.sleep(1000);
            System.out.print(" . ");
            Thread.sleep(1000);
            System.out.print(" . ");
            Thread.sleep(1000);
            System.out.println(" . ");
            Thread.sleep(1000);
            System.out.println("Thank you for waiting! Profile established. Membership valid for " + length + " days.");
        } catch (InterruptedException ex) {
            Logger.getLogger(GymAssignmentThree.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void pickedA(Scanner scan, Gym myGym){
        String userName;
        boolean exists = false;
        Member user = null;
        int length;
        Membership memberType = null;
        System.out.println("What's your name?");
        userName = scan.nextLine();
        for(Member m : myGym.getListM()){
            if(m.getName().equals(userName) ){
                user = m;
                exists = true;
            }
        }
        if(exists){
            System.out.println("Membership Length?");
            length = scan.nextInt();
            scan.nextLine();
            while((length != 30) && (length != 90) && (length != 365)){
                System.out.println("Available memberships are 30, 90, and 365 days long. Please choose a valid membership length");
                length = scan.nextInt();
            }
            if(length == 30){
                memberType = new FreeMonth();
            } else if(length == 90){
                memberType = new ThreeMonths();
            } else if(length == 365){
                memberType = new TwelveMonths();
            }
            user.buyMembership(memberType);
        } else {
            System.out.println("Please choose a name that exists...");
        }
    }
    public static void loopMembers(ArrayList<Member> listM){
        for(Member m : listM){
            System.out.println(m.getName());
        }
    }
    public static void primeManners(){
        try {
            System.out.println("Building new profile...");
            System.out.print("Loading");
            Thread.sleep(1000);
            System.out.print(" . ");
            Thread.sleep(1000);
            System.out.print(" . ");
            Thread.sleep(1000);
            System.out.println(" . ");
            Thread.sleep(1000);
            System.out.println("Thank you for waiting! Profile established. Membership valid for %s days.");
        } catch (InterruptedException ex) {
            Logger.getLogger(GymAssignmentThree.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
